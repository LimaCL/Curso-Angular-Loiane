import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cursos-form',
  templateUrl: './cursos-form.component.html',
  styleUrls: ['./cursos-form.component.scss']
})
export class CursosFormComponent implements OnInit {

  form!: FormGroup;
  submitted: boolean = false;

  constructor(private fb: FormBuilder) {
   }

  ngOnInit(): void {
    this.form = new FormGroup({
      nome: new FormControl("", [
        Validators.required,
        Validators.minLength(4),
      ])});

    }



  onSubmit(){
    this.submitted = true;
    console.log(this.form.value);
    if(this.form.valid){
      console.log('submit')
    }
  }

  onCancel(){
    this.submitted = false;
    this.form.reset;
    console.log('Cancel');
  }

  hasError(field: string){
    return this.form.get(field)?.errors;
  }
}
