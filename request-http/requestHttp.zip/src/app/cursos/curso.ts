export interface Curso {
    id: number;
    nome: string;
}